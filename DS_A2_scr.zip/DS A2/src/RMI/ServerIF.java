package RMI;

import scrabbleGame.PlayerAction;
import scrabbleGame.ScrabbleGameController;
import scrabbleGame.ScrabbleGameLobby;
import scrabbleGame.ScrabbleGameLobbyInfo;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 * @author 1
 */
public interface ServerIF extends Remote {
    //public ScrabbleGameLobbyController getLobby() throws Exception ;
    String getFreePlayers() throws RemoteException;

    void performAction(String playerName, PlayerAction action,
                       int row, int col, String letter) throws Exception;

    ScrabbleGameController getSpecificGame(String playerName) throws Exception;

    List<ScrabbleGameController> getGameList() throws Exception;

    /**
     * true for success，otherwise for fail
     *
     * @param controller
     * @return
     * @throws Exception
     */
    boolean addGame(ScrabbleGameController controller) throws Exception;

    ScrabbleGameLobbyInfo getGameLobbyData() throws Exception;

    //here
    void performAction(String playerName, PlayerAction action) throws Exception;

    void performAction(String playerName, PlayerAction action, int roomNm) throws Exception;

    void performAction(String playerName, PlayerAction action, String msg) throws Exception;

    void performAction(String playerName, PlayerAction action, String msg, int roomNm,
                       int row, int col, String letter) throws Exception;

    void performAction(String playerName, String playerName2, PlayerAction action) throws Exception;

    void addFreePlayers(String playerName) throws RemoteException;

    ScrabbleGameLobby getScrabbleGameLobby() throws RemoteException;

    void performAction(String playerName, PlayerAction action, String msg, int roomNm, int row, int col, String letter, String playerName2) throws Exception;

    void performPlayerAction(String playerName, PlayerAction action) throws Exception;

    /**
     * true indicate it is turn of playerName
     *
     * @param playerName
     * @return
     * @throws Exception
     */
    boolean checkTurn(String playerName) throws Exception;

    /**
     * exit game room
     *
     * @param playerName
     * @throws Exception
     */
    void exitRoom(String playerName) throws Exception;
}
