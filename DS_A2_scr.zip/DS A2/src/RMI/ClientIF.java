package RMI;

import GUI.GameLobbyGUI;

import java.rmi.Remote;

/**
 * @author 1
 */
public interface ClientIF extends Remote {
    GameLobbyGUI getGame() throws Exception;
}
