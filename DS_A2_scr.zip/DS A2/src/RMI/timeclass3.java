package RMI;

import java.util.TimerTask;

import GUI.GameGUI;


public class timeclass3 extends TimerTask {

	GameGUI game;
    public timeclass3(GameGUI game) {
        this.game=game;
    }

    @Override
    public void run() {
    	try {
			game.refresh2();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
