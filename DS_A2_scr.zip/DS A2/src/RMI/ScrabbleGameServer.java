package RMI;

import exceptions.ServerInitializeException;
import scrabbleGame.*;

import java.io.FileReader;
import java.io.Serializable;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.swing.JOptionPane;

/**
 * server bootstrap
 *
 * @author 1
 */
public class ScrabbleGameServer extends UnicastRemoteObject implements ServerIF, Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private static ScrabbleGameLobbyController lobbyController;

    static {
        try {
            lobbyController = new ScrabbleGameLobbyController("AppSettings.properties");
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    private int portNo;
    private String url;
    private String config;

    public ScrabbleGameServer() throws RemoteException {
        super();
    }

    /**
     * @param portNo
     * @param url
     * @param config
     * @throws RemoteException
     */
    public ScrabbleGameServer(int portNo, String url, String config) throws RemoteException {
        super();
        this.portNo = portNo;
        this.url = url;
        this.config = config;
        //TODO: did not successfully handle read config failed case
    }

    /**
     * process to bind to the stub
     *
     * @throws Exception
     */
    public void start() throws Exception {
        LocateRegistry.createRegistry(portNo);
        System.out.println(url);
        Naming.rebind(url, new ScrabbleGameServer(portNo, url, config));
    }

    public ScrabbleGameLobbyController getLobby() throws ServerInitializeException {
        if (lobbyController == null) {
            throw new ServerInitializeException(lobbyController.toString());
        }
        return lobbyController;
    }


    //assume in the real jar file user can enter the url
    public static void main(String args[]) {
        // translate url from args
        String url = new String();
        String config = new String();
        int portNo = -1;

        if (args.length < 3) {
            // pop up a window to indicates that insuciffient args, then using default value
            portNo = 1099;
            config = "AppSettings.properties";

            //loading server address from config file
            try (FileReader reader = new FileReader(config)) {
                Properties pro = new Properties();
                pro.load(reader);
                url = pro.getProperty("serverAddress");
            } catch (Exception e) {
                //TODO: popup a error
            	JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
        //build up new server
        try {
        	
            ScrabbleGameServer server = new ScrabbleGameServer(portNo, url, config);
            LocateRegistry.createRegistry(portNo);
            System.out.println(url);
            Naming.bind(url, server);
            //server.start();
            JOptionPane.showMessageDialog(null, String.format("Server Starts!\nPortNo: %d  Ip:%s Stub Name: %s",
            		portNo,"128.250.0.199" ,url));
            //TODO: Then open the server GUI
        } catch (Exception e) {
            //TODO: pop up a window to indicate the error
        	JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }

    /**
     * 获取用户
     *
     * @return
     * @throws Exception
     */
    @Override
    public String getFreePlayers() throws RemoteException {
        String playerListStr = lobbyController.getGameLobbyData().getPlayerList();
        if (playerListStr == null || playerListStr.equalsIgnoreCase("")) {
            playerListStr = lobbyController.getGameLobby().getPlayerList();
        }
        return playerListStr;
    }

    @Override
    public void performAction(String playerName, PlayerAction action, int row, int col, String letter) throws Exception {
        getSpecificGame(playerName).performAction(playerName, action, row, col, letter);
    }

    @Override
    public ScrabbleGameController getSpecificGame(String playerName) throws Exception {
        return lobbyController.getGameLobby().findGame(playerName);
    }

    @Override
    public List<ScrabbleGameController> getGameList() throws Exception {
        return lobbyController.getGameLobby().getGameList();
    }

    @Override
    public boolean addGame(ScrabbleGameController controller) throws Exception {
        return lobbyController.getGameLobby().addGame(controller);
    }

    @Override
    public ScrabbleGameLobbyInfo getGameLobbyData() throws Exception {
        ScrabbleGameLobbyInfo gameLobbyInfo = lobbyController.getGameLobbyData();
        gameLobbyInfo.setChatLog(lobbyController.getGameLobby().getChatLog());
        gameLobbyInfo.setPlayerActivitiesLog(lobbyController.getGameLobby().getPlayerActivityLog());
        gameLobbyInfo.setRoomActivityLog(lobbyController.getGameLobby().getRoomActivityLog());
        gameLobbyInfo.setPlayerList(lobbyController.getGameLobby().getPlayerList());
        gameLobbyInfo.setRoomList(lobbyController.getGameLobby().getRoomList());
        gameLobbyInfo.setInviteList(lobbyController.getGameLobby().getInviteList());
        return gameLobbyInfo;
    }

    @Override
    public void performAction(String playerName, PlayerAction action) throws Exception {
        lobbyController.getGameLobby().performAction(playerName, action);
    }

    @Override
    public void performAction(String playerName, PlayerAction action, int roomNm) throws Exception {
        lobbyController.getGameLobby().performAction(playerName, action, roomNm);
    }

    @Override
    public void performAction(String playerName, PlayerAction action, String msg) throws Exception {
        lobbyController.getGameLobby().performAction(playerName, action, msg);
    }

    @Override
    public void performAction(String playerName, PlayerAction action, String msg, int roomNm, int row, int col,
                              String letter) throws Exception {
        lobbyController.getGameLobby().performAction(playerName, action, msg, roomNm, row, col, letter, null);
    }

    @Override
    public void performAction(String playerName, String playerName2, PlayerAction action) throws Exception {
        lobbyController.getGameLobby().performAction(playerName, playerName2, action);
    }

    @Override
    public void addFreePlayers(String playerName) throws RemoteException {
        if (playerName == null || lobbyController == null || lobbyController.getGameLobby() == null) {
            return;
        }
        lobbyController.getGameLobby().addPlayerList(playerName);
    }

    @Override
    public ScrabbleGameLobby getScrabbleGameLobby() throws RemoteException {
        return lobbyController.getGameLobby();
    }

    @Override
    public void performAction(String playerName, PlayerAction action, String msg, int roomNm, int row, int col, String letter, String playerName2) throws Exception {

    }

    @Override
    public void performPlayerAction(String playerName, PlayerAction action) throws Exception {
        getSpecificGame(playerName).performAction(playerName, action);
    }

    @Override
    public boolean checkTurn(String playerName) throws Exception {
        if (playerName == null) {
            return false;
        }
        return playerName.equalsIgnoreCase(getSpecificGame(playerName).getGame().getPlayerTurn());
    }

    @Override
    public void exitRoom(String playerName) throws Exception {
        if (playerName == null) {
            return;
        }
        List<Player> players = lobbyController.getGameLobby().getAllPlayerList();
        if (players == null || players.size() < 1) {
            return;
        }
        Integer roomId = null;
        for (Player player : players) {
            if (player.getUserName().equalsIgnoreCase(playerName)) {
                roomId = player.getJoinedRoomId();
                player.setJoinedRoomId(0);
                break;
            }
        }

        //remove room
        if (roomId == null) {
            return;
        }
        List<ScrabbleGameController> gameControllers = lobbyController.getGameLobby().getGameList();
        if (gameControllers == null || gameControllers.size() < 1) {
            return;
        }

        //is there other player in this game?
        for (Player player : players) {
            if (!player.getUserName().equalsIgnoreCase(playerName)) {
                if (player.getJoinedRoomId() == roomId) {
                    return;
                }
            }
        }


        Iterator<ScrabbleGameController> itr = gameControllers.iterator();
        while (itr.hasNext()) {
            ScrabbleGameController gameController = itr.next();
            if (gameController.getControllerID() == roomId) {
                itr.remove();
                break;
            }
        }

    }

}
