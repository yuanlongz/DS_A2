
package RMI;

import GUI.GameLobbyGUI;

import javax.swing.*;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

/**
 * @author 1
 */
public class ScrabbleGameClient extends UnicastRemoteObject {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private GameLobbyGUI game;
    private String name;
    public static ServerIF lobbyProxy;

    public ScrabbleGameClient(ServerIF lobbyProxy) throws Exception {
        super();
        ScrabbleGameClient.lobbyProxy = lobbyProxy;
        System.out.println(lobbyProxy.hashCode());
        System.out.println(lobbyProxy.getFreePlayers());
        this.name = JOptionPane.showInputDialog("Enter your user name to Log In:");
        try {
            if (name == null || name.equalsIgnoreCase("")){
                System.exit(0);
            }
            game = new GameLobbyGUI(name, lobbyProxy);
            game.run();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void main(String args[]) {
    	if (args.length < 1)
    	{
    		JOptionPane.showMessageDialog(null, "The port number has not been inputed use default localhost");
  
    		try {
    			//ScrabbleGameServer server = new ScrabbleGameServer(1099, "RMI_CONNECTION", "AppSettings.properties");
    			//Registry registry = LocateRegistry.getRegistry("10.13.193.197", 1099);
    			//ScrabbleGameServer server = (ScrabbleGameServer) registry.lookup("RMI_CONNECTION");

    			ServerIF look_up = (ServerIF) LocateRegistry.getRegistry("localhost").lookup("RMI_CONNECTION");
    			JOptionPane.showMessageDialog(null, "Connected to Server! IP" + "localhost");
    			new ScrabbleGameClient(look_up); 
    			
    		} catch (Exception e) {
    			JOptionPane.showMessageDialog(null, e.getMessage());
    		}
    	}else {
    		try {
    			//ScrabbleGameServer server = new ScrabbleGameServer(1099, "RMI_CONNECTION", "AppSettings.properties");
    			//Registry registry = LocateRegistry.getRegistry("10.13.193.197", 1099);
    			//ScrabbleGameServer server = (ScrabbleGameServer) registry.lookup("RMI_CONNECTION");
    			ServerIF look_up = (ServerIF) Naming.lookup("//"+args[0]+":1099/RMI_CONNECTION");
    			//ServerIF look_up = (ServerIF) LocateRegistry.getRegistry(args[0]).lookup("RMI_CONNECTION");
    			JOptionPane.showMessageDialog(null, "Connected to Server! "+ args[0]);
    			new ScrabbleGameClient(look_up);
    			
    		} catch (Exception e) {
    			JOptionPane.showMessageDialog(null, e.getMessage());
    		}
    	}
    }

    public GameLobbyGUI getGame() {
        return game;
    }

}
