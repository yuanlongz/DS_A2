package RMI;

import java.util.TimerTask;

import GUI.GameGUI;


public class timeclass2 extends TimerTask {

	GameGUI game;
    public timeclass2(GameGUI game) {
        this.game=game;
    }

    @Override
    public void run() {
    	try {
			game.refresh1();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
