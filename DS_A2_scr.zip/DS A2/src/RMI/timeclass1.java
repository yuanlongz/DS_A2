package RMI;

import java.util.TimerTask;

import GUI.GameGUI;

public class timeclass1 extends TimerTask {

	GameGUI game;
    public timeclass1(GameGUI game) {
        this.game=game;
    }

    @Override
    public void run() {
    	try {
			game.refresh();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
