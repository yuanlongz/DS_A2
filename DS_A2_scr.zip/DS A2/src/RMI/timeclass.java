package RMI;

import java.util.TimerTask;

import GUI.GameLobbyGUI;

public class timeclass extends TimerTask {

	GameLobbyGUI game;
    public timeclass(GameLobbyGUI game) {
        this.game=game;
    }

    @Override
    public void run() {
    	try {
			game.refresh();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
