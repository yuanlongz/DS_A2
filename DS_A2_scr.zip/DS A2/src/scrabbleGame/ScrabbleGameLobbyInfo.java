package scrabbleGame;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 1
 */
public class ScrabbleGameLobbyInfo implements Serializable {
    private String chatLog;
    private String playerActivitiesLog;
    private String roomActivityLog;
    private String roomList;
    private String playerList;
    private Map<String, String> inviteList;

    public ScrabbleGameLobbyInfo() {
        super();
        this.chatLog = new String();
        this.playerActivitiesLog = new String();
        this.roomActivityLog = new String();
        this.playerList = new String();
        this.roomList = new String();
        this.inviteList = new HashMap<>();
    }

    public String getChatLog() {
        return chatLog;
    }

    public void setChatLog(String chatLog) {
        this.chatLog = chatLog;
    }

    public String getPlayerActivitiesLog() {
        return playerActivitiesLog;
    }

    public void setPlayerActivitiesLog(String playerActivitiesLog) {
        this.playerActivitiesLog = playerActivitiesLog;
    }

    public String getRoomActivityLog() {
        return roomActivityLog;
    }

    public void setRoomActivityLog(String roomActivityLog) {
        this.roomActivityLog = roomActivityLog;
    }

    public String getPlayerList() {
        return playerList;
    }

    public void setPlayerList(String playerList) {
        this.playerList = playerList;
    }

    public String getRoomList() {
        return roomList;
    }

    public void setRoomList(String roomList) {
        this.roomList = roomList;
    }

    public Map<String, String> getInviteList() {
        return inviteList;
    }

    public void setInviteList(Map<String, String> inviteList) {
        this.inviteList = inviteList;
    }


}
