package scrabbleGame;

import java.io.Serializable;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 * @author 1
 */
public class ScrabbleGameLobbyController extends UnicastRemoteObject implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    //TO BE Extend to ArrayList to simulate muti-server
    private ScrabbleGameLobbyInfo gameLobbyData;
    private ScrabbleGameLobby gameLobby;

    public ScrabbleGameLobbyInfo getGameLobbyData() {
        return gameLobbyData;
    }

    public void setGameLobbyData(ScrabbleGameLobbyInfo gameLobbyData) {
        this.gameLobbyData = gameLobbyData;
    }

    public ScrabbleGameLobby getGameLobby() {
        return gameLobby;
    }

    public void setGameLobby(ScrabbleGameLobby gameLobby) {
        this.gameLobby = gameLobby;
    }
    //private static ServerIF look_up;

    public static void main(String args[]) {

        try {
            ScrabbleGameLobbyController server = new ScrabbleGameLobbyController
                    ("AppSettings.properties");
            Registry reg = LocateRegistry.createRegistry(1099);
            Naming.bind("RMI_CONNECTION", server);
            System.out.println("server start..");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        //System.out.println(url);

    }


    public ScrabbleGameLobbyController(String config) throws RemoteException {
        super();
        gameLobby = new ScrabbleGameLobby(config);
        gameLobbyData = new ScrabbleGameLobbyInfo();
    }


    /**
     * Handle player actions like: create game, Logout, Pass turn, Start Game, Vote
     *
     * @param playerName
     * @param action
     * @throws Exception
     */
//    @Override
//    public void performAction(String playerName, PlayerAction action) throws Exception {
//        gameLobby.performAction(playerName, action);
//    }


    /**
     * Handle player actions like: join room
     *
     * @param playerName
     * @param action
     * @param roomNm
     * @throws Exception
     */
//    @Override
//    public void performAction(String playerName, PlayerAction action, int roomNm) throws Exception {
//        gameLobby.performAction(playerName, action, roomNm);
//    }


    /**
     * Handle player actions like: chat
     *
     * @param playerName
     * @param action
     * @param msg
     * @throws Exception
     */
//    @Override
//    public void performAction(String playerName, PlayerAction action, String msg) throws Exception {
//        gameLobby.performAction(playerName, action, msg);
//    }

    /**
     * Handle player actions like: invite
     *
     * @param playerName
     * @param playerName2
     * @param action
     * @throws Exception
     */
//    @Override
//    public void performAction(String playerName, String playerName2, PlayerAction action) throws Exception {
//        gameLobby.performAction(playerName, playerName2, action);
//    }

//    @Override
//    public void addFreePlayers(String playerName) {
//
//    }

    /**
     * Handle all other normal game actions
     *
     * @param playerName
     * @param roomNm
     * @param msg
     * @param action
     * @param row
     * @param col
     * @param letter
     * @throws Exception
     */
//    @Override
//    public void performAction(String playerName, PlayerAction action, String msg, int roomNm,
//                              int row, int col, String letter) throws Exception {
//        gameLobby.performAction(playerName, action, msg, roomNm, row, col, letter, null);
//    }

//    @Override
//    public ScrabbleGameLobbyInfo getGameLobbyData() {
//        gameLobbyData.setChatLog(gameLobby.getChatLog());
//        gameLobbyData.setPlayerActivitiesLog(gameLobby.getPlayerActivityLog());
//        gameLobbyData.setRoomActivityLog(gameLobby.getRoomActivityLog());
//        gameLobbyData.setPlayerList(gameLobby.getPlayerList());
//        gameLobbyData.setRoomList(gameLobby.getRoomList());
//        gameLobbyData.setInviteList(gameLobby.getInviteList());
//        return gameLobbyData;
//    }

    //for test propuse
//    @Override
//    public String getFreePlayers() {
//        String freeList = new String("Avilable players:\n\n");
//        for (Player player : gameLobby.getFreePlayerList()) {
//            freeList += player.getUserName() + "\n";
//        }
//        return freeList += "\n";
//    }

    //To passing the game data to players
//    @Override
//    public ScrabbleGameController getSpecificGame(String playerName) throws
//            NoGameDataCreatedException, UserNotExistException, GameNotCreatedException {
//        return gameLobby.findGame(playerName);
//    }
}
