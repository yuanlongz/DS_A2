package GUI;

import RMI.ScrabbleGameServer;
import RMI.ServerIF;
import RMI.timeclass;
import exceptions.ServerInitializeException;
import scrabbleGame.PlayerAction;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;

public class GameLobbyGUI {
    //Scrabble Game lobbyProxy realated attributes
    private String playerName;
    public ServerIF lobbyProxy;
    private ScrabbleGameServer server;


    private JFrame frame;
    private JTextArea txtrPlayerList;
    private JButton btnNewGame;
    private JTextArea txtrRoomlist;
    private JButton btnJoinRoom;
    private JButton btnExitGame;
    private JButton btnGamerules;

    /**
     * Launch the application.
     */
    public void run() {
        EventQueue.invokeLater(() -> {
            try {
                GameLobbyGUI window = new GameLobbyGUI(playerName, lobbyProxy);
			    Timer timer = new Timer();
		        timeclass myTask = new timeclass(window);
		        timer.schedule(myTask, 100L, 100L);
                lobbyProxy.performAction(playerName, PlayerAction.LOG_IN);
                window.frame.setVisible(true);

            } catch (Exception e) {
                popException(e, "Failed to initialize Lobby");
            }
        });
    }

    /**
     * Create the application.
     *
     * @throws ServerInitializeException
     */
    public GameLobbyGUI(String playerName, ServerIF lobby) {
        //this.server = server;
        this.lobbyProxy = lobby;
        this.playerName = playerName;
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 486, 427);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.setTitle(String.format("Scrabble Game Lobby - loged in as <%s>", playerName));

        txtrPlayerList = new JTextArea();
        txtrPlayerList.setEditable(false);
        txtrPlayerList.setLineWrap(true);
        txtrPlayerList.setWrapStyleWord(true);
        txtrPlayerList.setText("playerList");
        txtrPlayerList.setBounds(10, 11, 125, 215);
        frame.getContentPane().add(txtrPlayerList);

        JScrollPane jsp = new JScrollPane(txtrPlayerList, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        jsp.setBounds(10, 11, 145, 215);
        frame.getContentPane().add(jsp);

        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> {
            try {
                refresh();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        });

        btnNewGame = new JButton("New Game");
        btnNewGame.addActionListener(e -> {
            try {

                int n = JOptionPane.showConfirmDialog(null,
                        "Start a new game? ", "Create Game",
                        JOptionPane.YES_NO_OPTION);
                if (n == 0) {
                    createNewGame();
                } else {
                    refresh();
                }

            } catch (Exception e1) {
                popException(e1, "Create Game Error");
            }
        });

        txtrRoomlist = new JTextArea();
        txtrRoomlist.setEditable(false);
        txtrRoomlist.setLineWrap(true);
        txtrRoomlist.setWrapStyleWord(true);
        txtrRoomlist.setText("RoomList");
        txtrRoomlist.setBounds(10, 237, 125, 215);
        frame.getContentPane().add(txtrRoomlist);

        JScrollPane jsp2 = new JScrollPane(txtrRoomlist, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        jsp2.setBounds(188, 11, 230, 215);
        frame.getContentPane().add(jsp2);

        btnNewGame.setBounds(10, 323, 111, 35);
        frame.getContentPane().add(btnNewGame);
        btnRefresh.setBounds(10, 259, 111, 35);
        frame.getContentPane().add(btnRefresh);

        btnJoinRoom = new JButton("Join Room");
        btnJoinRoom.addActionListener(e -> {

            try {
                String room = JOptionPane.showInputDialog("Please Enter the 4 digit Room ID: ");
                joinGame(Integer.parseInt(room));
            } catch (Exception e1) {
                popException(e1, "Join Room Error");
            }
        });
        btnJoinRoom.setBounds(179, 259, 111, 35);
        frame.getContentPane().add(btnJoinRoom);

        btnExitGame = new JButton("Exit Game");
        btnExitGame.addActionListener(e -> {
            try {
                int n = JOptionPane.showConfirmDialog(null,
                        "Exit? ", "Exit Game",
                        JOptionPane.YES_NO_OPTION);
                if (n == 0) {
                    lobbyProxy.performAction(playerName, PlayerAction.LOGOUT_LOBBY);
                    frame.dispose();
                } else {
                    refresh();
                }

            } catch (Exception err) {
                popException(err, "Exit Error");
            }

        });
        btnExitGame.setBounds(179, 323, 111, 35);
        frame.getContentPane().add(btnExitGame);

        btnGamerules = new JButton("GameRules");
        btnGamerules.addActionListener(e -> {
            String info = "Scabble game rules" + "\n"
                    + "1. The game is played by one to five players on a square board with a 20×20 grid of cells."
                    + "\n" + "2. Player can create a room and invite friends to play togther or play alone." + "\n"
                    + "3. Player can communicate with each other(online players) through chat window." + "\n"
                    + "4. When the game start, the player in its turn can add a letter or pass its turn." + "\n"
                    + "5. A player can only add one letter in its turn, numbers or more than one letter are invalid."
                    + "\n"
                    + "6. After a letter is added, voting procedure will start and score according to vote result."
                    + "\n" + "7. If there is same word in different place, it still counts.";

            // JOptionPane.showMessageDialog(null, info, "Game Rules",
            // JOptionPane.INFORMATION_MESSAGE);
            createFrame("Game Rules", info);
        });
        btnGamerules.setBounds(331, 259, 111, 35);
        frame.getContentPane().add(btnGamerules);
    }

    public static void createFrame(String title, String message) {
        EventQueue.invokeLater(() -> {

            JFrame frame = new JFrame(title);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setOpaque(true);
            JTextArea textArea = new JTextArea(15, 50);
            textArea.setText(message);
            textArea.setWrapStyleWord(true);
            textArea.setEditable(false);
            textArea.setFont(Font.getFont(Font.SANS_SERIF));
            JScrollPane scroller = new JScrollPane(textArea);
            scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
            scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

            DefaultCaret caret = (DefaultCaret) textArea.getCaret();
            caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
            panel.add(scroller);

            frame.getContentPane().add(BorderLayout.CENTER, panel);
            frame.pack();
            frame.setLocationByPlatform(true);
            frame.setVisible(true);
            frame.setResizable(false);
        });
    }

    private void popException(Exception e, String title) {
        JOptionPane.showMessageDialog(null, e.toString(), title,
                JOptionPane.ERROR_MESSAGE);
    }


    private void createNewGame() throws Exception {
        lobbyProxy.performAction(playerName, PlayerAction.CREATE_GAME);
        //generate a new game GUI
        GameGUI scrabbleGame = new GameGUI(playerName, lobbyProxy);
        scrabbleGame.run();
    }

    private void joinGame(int roomId) throws Exception {
        lobbyProxy.performAction(playerName, PlayerAction.JOIN_GAME, roomId);
        //generate a new game GUI
        GameGUI scrabbleGame = new GameGUI(playerName, lobbyProxy);
        scrabbleGame.run();
    }

    private void exitGame() {
        System.exit(0);
    }

    private void checkInvite() throws Exception {
        Map<String, String> inviteList = lobbyProxy.getGameLobbyData().getInviteList();
        //if you been invited
        if (inviteList.containsKey(playerName)) {
            String invitor = inviteList.get(playerName);
            try {
                int n = JOptionPane.showConfirmDialog(null,
                        String.format("%s has invited you to join his/her game.\nAccept?", invitor), "Invitation ",
                        JOptionPane.YES_NO_OPTION);
                if (n == 0) {
                    lobbyProxy.performAction(playerName, PlayerAction.ACCEPT_INVITE);
                    //generate a new game GUI
                    GameGUI scrabbleGame = new GameGUI(playerName, lobbyProxy);
                    scrabbleGame.run();
                } else {
                    lobbyProxy.performAction(playerName, PlayerAction.REJECT_INVITE);
                }
            } catch (Exception err) {
                popException(err, "Invitaion Error");
            }
        }
    }

    public void refresh() throws Exception {
        txtrPlayerList.setText(lobbyProxy.getGameLobbyData().getPlayerList());
        txtrRoomlist.setText(lobbyProxy.getGameLobbyData().getRoomList());
        checkInvite();
    }

}
