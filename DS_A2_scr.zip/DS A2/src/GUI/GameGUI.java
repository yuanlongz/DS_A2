package GUI;

import RMI.ServerIF;
import RMI.timeclass1;
import RMI.timeclass2;
import RMI.timeclass3;
import exceptions.GameNotCreatedException;
import exceptions.NoGameDataCreatedException;
import exceptions.WrongTurnToPlayException;
import scrabbleGame.PlayerAction;
import scrabbleGame.ScrabbleGameController;
import scrabbleGame.ScrabbleGameInfo;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Timer;
import static RMI.ScrabbleGameClient.lobbyProxy;

/**
 * @author 1
 */
public class GameGUI {

    private String playerName;
    private String votedWord = null;
    private JFrame frame;
    private JTextField[][] cells;
    private JLabel lblCurrentTurn;
    private JTextArea txtrPhase;
    private JTextArea txtrRank;
    private JScrollPane sbrText;
    private JButton btnPass;
    private JButton btnLogOut;
    private JTextArea txtrGameLog;
    private JButton btnStart;
    private JButton btnInvite;


    /**
     * Launch the application.
     */
    public void run() {
        EventQueue.invokeLater(() -> {
            try {
                GameGUI window = new GameGUI(playerName, lobbyProxy);
                window.frame.setVisible(true);
			    Timer timer = new Timer();
                timeclass1 myTask = new timeclass1(window);
		        timeclass2 myTask1= new timeclass2(window);
		        timeclass3 myTask2=new timeclass3(window);
		        timer.schedule(myTask, 300L, 300L);
		        timer.schedule(myTask1, 300L, 8000L);
		        timer.schedule(myTask2, 300L, 3000L);

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }


    /**
     * Create the application.
     */
    public GameGUI(String playerName, ServerIF lobby) {
        try {
            //initialize attributes
            this.playerName = playerName;
            // chaneg the link to RMI later
            initialize();
        } catch (Exception e) {
            popException(e, "Initialize Game Error");
        }
    }

    /**
     * Initialize the contents of the frame.
     *
     * @throws Exception
     */
    private void initialize() throws Exception {
        frame = new JFrame();
        frame.setTitle(playerName + "'s GameWindow\n");
        frame.setBounds(100, 100, 909, 620);
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBounds(205, 11, 519, 411);

        renderGameBoard(panel);


        // Add button
        JButton btnAdd = new JButton("Add");
        btnAdd.setBounds(779, 101, 89, 23);
        btnAdd.addActionListener(e -> {
            //An arraylist contains following data [numberOfNewWriteDowns, theLastUpdateRow, theLastUpdateCol]
            ArrayList<Integer> newWordData = null;
            try {
                newWordData = scanBoard();
            } catch (Exception e1) {
                popException(e1, "scan board error!");
                e1.printStackTrace();
                return;
            }
            //write down new word
            writeWord(newWordData);

        });
        frame.getContentPane().setLayout(null);
        frame.getContentPane().add(panel);
        panel.setLayout(new GridLayout(20, 20, 0, 0));

        btnStart = new JButton("Start");
        btnStart.addActionListener(e -> {
            try {
                int n = JOptionPane.showConfirmDialog(null,
                        "Start now?", "Start Game",
                        JOptionPane.YES_NO_OPTION);
                if (n == 0) {
                    lobbyProxy.performAction(playerName, PlayerAction.START_GAME, 0, 0, null);
//                    lobbyProxy.getSpecificGame(playerName).performAction(playerName, PlayerAction.START_GAME);
                } else {
                    refresh();
                }
            } catch (Exception e1) {
                popException(e1, "Start Game Error");
            }
        });
        btnStart.setBounds(779, 29, 89, 23);
        frame.getContentPane().add(btnStart);

        btnInvite = new JButton("Invite");
        btnInvite.addActionListener(e -> {
            try {
                String otherPlayer = JOptionPane.showInputDialog(lobbyProxy.getFreePlayers());
                if (otherPlayer != null) {
                    invitePlayer(otherPlayer);
                }
            } catch (Exception err) {
                popException(err, "Inivite Error");
            }


        });
        btnInvite.setBounds(779, 67, 89, 23);
        frame.getContentPane().add(btnInvite);
        frame.getContentPane().add(btnAdd);

        //: Pass button
        btnPass = new JButton("Pass");
        btnPass.addActionListener(e -> {
            try {
                int n = JOptionPane.showConfirmDialog(null,
                        "(.•́︿•̀｡) You will pass this turn.", "Pass Turn",
                        JOptionPane.YES_NO_OPTION);
                if (n == 0) {
                    if (!lobbyProxy.checkTurn(playerName)) {
                        popException(new WrongTurnToPlayException(playerName), "Wrong turn!");
                        return;
                    }
                    lobbyProxy.performAction(playerName, PlayerAction.PASS_TURN, 0, 0, null);
//                    lobbyProxy.performAction(playerName, PlayerAction.PASS_TURN);
                } else {
                    refresh();
                }
            } catch (Exception err) {
                popException(err, "Passing Turn Error");
            }

        });
        btnPass.setBounds(779, 145, 89, 23);
        frame.getContentPane().add(btnPass);

        //: Log Out
        btnLogOut = new JButton("Log Out");
        btnLogOut.addActionListener(e -> {
            try {
                int n = JOptionPane.showConfirmDialog(null,
                        "(´-ι_-｀) Really don't want to play few more mins? ", "Log Out",
                        JOptionPane.YES_NO_OPTION);
                if (n == 0) {
                    lobbyProxy.performAction(playerName, PlayerAction.LOGOUT, 0, 0, null);

//                    lobbyProxy.performAction(playerName, PlayerAction.LOGOUT);
                    refresh();
                } else {
                    refresh();
                }
            } catch (Exception err) {
                popException(err, "Log Out Error");
            }
        });
        btnLogOut.setBounds(779, 202, 89, 23);
        frame.getContentPane().add(btnLogOut);

        //TODO: Refresh Button
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.setBounds(779, 271, 89, 23);
        btnRefresh.addActionListener(e -> {
            try {
                refresh();
                refresh1();
                refresh2();
            } catch (Exception e1) {
                popException(e1, "Refresh Game Error");
            }

        });
        frame.getContentPane().add(btnRefresh);

        lblCurrentTurn = new JLabel("CurrentTurn");
        lblCurrentTurn.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblCurrentTurn.setBounds(30, 11, 134, 23);
        frame.getContentPane().add(lblCurrentTurn);

        txtrPhase = new JTextArea();
        txtrPhase.setText("CurrentTurn");
        txtrPhase.setWrapStyleWord(true);
        txtrPhase.setLineWrap(true);
        txtrPhase.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtrPhase.setEditable(false);
        txtrPhase.setBounds(30, 45, 134, 40);
        frame.getContentPane().add(txtrPhase);

        txtrRank = new JTextArea();
        txtrRank.setEditable(false);
        txtrRank.setWrapStyleWord(true);
        txtrRank.setText("PlayerRank");
        txtrRank.setBounds(30, 115, 134, 101);
        frame.getContentPane().add(txtrRank);

        txtrGameLog = new JTextArea();
        txtrGameLog.setEditable(false);
        txtrGameLog.setLineWrap(true);
        txtrGameLog.setWrapStyleWord(true);
        txtrGameLog.setBounds(30, 443, 778, 110);

        frame.getContentPane().add(txtrGameLog);

        JScrollPane jsp = new JScrollPane(txtrRank, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        jsp.setBounds(30, 115, 134, 101);
        frame.getContentPane().add(jsp);

        JScrollPane jsp2 = new JScrollPane(txtrGameLog, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        jsp2.setBounds(30, 443, 838, 110);
        frame.getContentPane().add(jsp2);

    }

    /**
     * @param err
     */
    private void popException(Exception err, String title) {
        JOptionPane.showMessageDialog(null, err.toString(), title,
                JOptionPane.ERROR_MESSAGE);
    }


    private void renderGameBoard(JPanel panel) throws Exception {
        ScrabbleGameInfo gameInfo = lobbyProxy.getSpecificGame(playerName).getGameData();

        cells = new JTextField[gameInfo.getRows()][gameInfo.getColums()];
        //TODO change rows back to dynamic??Problem, can't actually do dynamic dividing
        panel.setLayout(new GridLayout(20, gameInfo.getColums(), 0, 0));
        //create a rows*cols size gameboard
        for (int i = 0; i < gameInfo.getRows(); i++) {
            for (int j = 0; j < gameInfo.getColums(); j++)
            //text is inisized to null
            {
                panel.add(cells[i][j] = new JTextField());
            }
        }
    }

    /**
     * A method to find how many cells has been updated
     *
     * @return ArrayList<Integer> [numberOfNewWriteDowns, theLastUpdateRow,
     * theLastUpdateCol]
     */
    private ArrayList<Integer> scanBoard() throws Exception {
        // An arraylist contains following data [numberOfNewWriteDowns,
        // theLastUpdateRow, theLastUpdateCol]
        ArrayList<Integer> result = new ArrayList<Integer>();
        boolean test3, test2;
        int counter = 0;
        int changedRow = -1;
        int changedCol = -1;
        String newCell, oldCell;
        ScrabbleGameInfo gameInfo = lobbyProxy.getSpecificGame(playerName).getGameData();
        // find newly writed word
        for (int i = 0; i < gameInfo.getRows(); i++) {
            for (int j = 0; j < gameInfo.getColums(); j++) {

                try {
                    newCell = lobbyProxy.getSpecificGame(playerName).getGameData().getGameBoard()[i][j];
                    oldCell = cells[i][j].getText();
                    test2 = (oldCell.isEmpty());
                    test3 = oldCell.equals(newCell);
                    if (!test2 && !test3) {
                        changedCol = j;
                        changedRow = i;
                        counter++;
                    }
                } catch (NoGameDataCreatedException | GameNotCreatedException e1) {
                    popException(e1, "Scan Board Error");
                } catch (Exception e) {
                    popException(e, "try to handle e");
                }
            }
        }

        result.add(counter);
        result.add(changedRow);
        result.add(changedCol);

        return result;
    }


    /**
     * Trying to write word to the game, but with some conditions applied on it
     *
     * @param newWordData
     */
    private void writeWord(java.util.List<Integer> newWordData) {
        int changedWordNm = newWordData.get(0);
        int changedRow = newWordData.get(1);
        int changedCol = newWordData.get(2);

        if (changedWordNm == 1) {
            JOptionPane.showConfirmDialog(null, "ヾ(◍'౪`◍)ﾉﾞ  Want to add this letter?", "Letter confirm",
                    JOptionPane.YES_NO_OPTION);
            // action write down a letter sent to the server
            try {
                if (!lobbyProxy.checkTurn(playerName)) {
                    popException(new WrongTurnToPlayException(playerName), "Wrong turn!");
                    return;
                }
                lobbyProxy.performAction(playerName, PlayerAction.WRITE_DOWN_LETTER
                        , changedRow, changedCol, cells[changedRow][changedCol].getText());
            } catch (Exception e1) {
                popException(e1, "Write Down Word Error");
            }
        } else if (changedWordNm < 1) {
            JOptionPane.showMessageDialog(null, "(。-`ω´-) You haven't add any letter!", "Adding letter error!",
                    JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "(๑°ㅁ°๑)ᵎᵎᵎ You have added more than one letter!", "Adding letter error!",
                    JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * synicize the local board with the game data
     */
    private void updateLocalBoard() throws Exception {
        ScrabbleGameController controller = lobbyProxy.getSpecificGame(playerName);
        if (controller == null) {
            return;
        }
        ScrabbleGameInfo gameInfo = controller.getGameData();
        for (int i = 0; i < gameInfo.getRows(); i++) {

            for (int j = 0; j < gameInfo.getColums(); j++) {
                try {
                    cells[i][j].setText(lobbyProxy.getSpecificGame(playerName).getGameData().getGameBoard()[i][j]);
                } catch (NoGameDataCreatedException | GameNotCreatedException e1) {
                    popException(e1, "Update Board Error");
                } catch (Exception e) {
                    popException(e, "unknown exception");
                }
            }
        }
    }

    private void checkVoting() throws Exception {
        boolean isTimeToVote = lobbyProxy.getSpecificGame(playerName).getGameData().isTimeToVote();
        //System.out.println("is time to vote:"+lobbyProxy.getSpecificGame(playerName).getGameData().isTimeToVote());
        // String isTimeToVote = lobbyProxy.getSpecificGame(playerName).getGameData().getCurrentPhase();
        System.out.println("current phase :" + isTimeToVote);
        String wordToVote = lobbyProxy.getSpecificGame(playerName).getGameData().getVotedWord();

        //if player need to vote
        if (isTimeToVote) {
            //is the player has voted for this word, prevent duplicate voting
            if (votedWord != null && votedWord.equalsIgnoreCase(wordToVote)) {
                //do Nothing
            } else {
                int n = JOptionPane.showConfirmDialog(null,
                        "π_π Do you agree \"" + lobbyProxy.getSpecificGame(playerName).getGameData().getVotedWord() + "\" is a word?", "Vote",
                        JOptionPane.YES_NO_OPTION);
                if (n == 0) {
                    PlayerAction action1 = PlayerAction.ACCEPT_WORD;
                    lobbyProxy.performAction(playerName, action1, 0, 0, null);
//                    lobbyProxy.performAction(playerName, action1);
                } else {
                    PlayerAction action2 = PlayerAction.REJECT_WORD;
                    lobbyProxy.performAction(playerName, action2, 0, 0, null);
//                    lobbyProxy.getSpecificGame(playerName).performAction(playerName, action2);
                }
                //update the player's voting history
                votedWord = wordToVote;
            }

        }
    }

    private void checkGameEnding() throws Exception {
        String phase = lobbyProxy.getSpecificGame(playerName).getGameData().getCurrentPhase();
        if (phase.equalsIgnoreCase("ENDING")) {
            JOptionPane.showMessageDialog(null, "( • ̀ω•́ )✧ The Game Ends !", "Warning", JOptionPane.INFORMATION_MESSAGE);
            JOptionPane.showMessageDialog(null, lobbyProxy.getSpecificGame(playerName).getGameData().getPlayerRank(), "Ranking",
                    JOptionPane.INFORMATION_MESSAGE);
            JOptionPane.showMessageDialog(null, "( • ̀ω•́ )✧ Now you will go back to game waiting room !", "Warning",
                    JOptionPane.INFORMATION_MESSAGE);
            lobbyProxy.exitRoom(playerName);
            this.frame.setVisible(false);
        }
    }

    private void invitePlayer(String otherPlayer) throws Exception {
        lobbyProxy.performAction(playerName, otherPlayer, PlayerAction.INVITE_PLAYER);
    }

    public void refresh() throws Exception {
        //format1: Every text field need to be updated here
        //format2: Every flag detection happens here
        ScrabbleGameController controller = lobbyProxy.getSpecificGame(playerName);
        if (controller != null) {
            lblCurrentTurn.setText("Current player: " + playerName);
            txtrPhase.setText("Current Phase: \n" + lobbyProxy.getSpecificGame(playerName).getGameData().getCurrentPhase());
            txtrRank.setText(lobbyProxy.getSpecificGame(playerName).getGameData().getPlayerRank());
            txtrGameLog.setText(lobbyProxy.getSpecificGame(playerName).getGameData().getGameLog());
            checkVoting();

        }

    }
    public void refresh1() throws Exception {
        updateLocalBoard();
    }
    public void refresh2() throws Exception {
        checkGameEnding();
    }
}
