package exceptions;

public class ServerInitializeException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String item;

	public ServerInitializeException(String item) {
		super();
		this.item = item;
	}

	@Override
	public String toString() {
		return String.format("ERROR: Can not get %s from server, as the result is null.\n", item);
	}
	
}
