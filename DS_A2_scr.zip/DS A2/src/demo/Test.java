package demo;

import GUI.GameLobbyGUI;
import scrabbleGame.*;

import java.rmi.RemoteException;

public class Test {
	public static ScrabbleGameController game;
	public static ScrabbleGameLobbyController lobby;
	
	public ScrabbleGameController getGame() {
		return game;
	}
	
	
	public Test(String config) throws RemoteException {
		Test.game = new ScrabbleGameController(config, 0);
		Test.lobby = new ScrabbleGameLobbyController(config);
	}
	
	public static void main (String args[]) {
		
		try{	
			Test test = new Test("AppSettings.properties");
			//lobbyProxy.performAction("JIM", PlayerAction.LOG_IN);
			//lobbyProxy.performAction("TIM", PlayerAction.LOG_IN);
			
//			GameLobbyGUI player1 = new GameLobbyGUI("JIM", lobbyProxy);
//			GameLobbyGUI player2 = new GameLobbyGUI("TIM", lobbyProxy);
//
//			player1.run();
//			player2.run();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	

	
}
